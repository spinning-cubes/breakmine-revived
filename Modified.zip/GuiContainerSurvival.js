import GuiContainer from "../GuiContainer.js";
import ContainerSurvival from "../../../inventory/container/ContainerSurvival.js";
import InventoryBasic from "../../../inventory/inventory/InventoryBasic.js";
import RecipeBook from "../../RecipeBook.js";

export default class GuiContainerSurvival extends GuiContainer {

    static inventory = new InventoryBasic();
    static SHIFT_X = 78;

    constructor(player) {
        super(new ContainerSurvival(player));

        this.inventoryWidth = 195;
        this.inventoryHeight = 165;

        this.cantPauseGame = true;
        this.baseX = 0;
    }

    init() {
        this.textureInventory = this.getTexture("gui/container/inventory.png");

        this.recipeBook = new RecipeBook(this.minecraft);
        this.recipeBook.init();

        super.init();
        this.baseX = this.x;
        this.applyRecipeBookOffset();
    }

    applyRecipeBookOffset() {
        if (this.recipeBook && this.recipeBook.isOpen()) {
            this.x = this.baseX + GuiContainerSurvival.SHIFT_X;
        } else {
            this.x = this.baseX;
        }
    }

    drawTitle(stack) {
        //this.drawString(stack, "Inventory", this.x + 8, this.y + 6, 0xff404040, false);
    }

    drawInventoryBackground(stack) {
        this.drawSprite(
            stack,
            this.textureInventory,
            0,
            0,
            this.inventoryWidth,
            this.inventoryHeight,
            this.x,
            this.y,
            this.inventoryWidth,
            this.inventoryHeight
        );
    }

    drawScreen(stack, mouseX, mouseY, partialTicks) {
        super.drawScreen(stack, mouseX, mouseY, partialTicks);

        if (this.minecraft.player) this.recipeBook.checkUnlock(this.minecraft.player.inventory);
        this.recipeBook.drawGui(stack, this.x - 5 - 150, this.y);
        this.recipeBook.draw(stack, this.x, this.y, mouseX, mouseY);
    }

    mouseClicked(mouseX, mouseY, mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);

        if (this.recipeBook.onClick(mouseX, mouseY, this.x, this.y)) {
            this.applyRecipeBookOffset();
        }
    }

    keyTyped(key, character) {
        if (this.recipeBook.handleKey(key, character)) return true;

        if (key === this.minecraft.settings.keyOpenInventory) {
            this.recipeBook.setOpen(false);
            this.minecraft.displayScreen(null);
            return true;
        }

        return super.keyTyped(key, character);
    }

}