import Gui from "./Gui.js";
import ItemStack from "../item/ItemStack.js";
import Block from "../world/block/Block.js";

export default class RecipeBook extends Gui {

    static unlocked = false;

    constructor(minecraft) {
        super(minecraft);

        this.textureToggle = null;
        this.textureBtn = null;
        this.textureBtnHover = null;
        this.textureGui = null;
        this.textureRecipeT = null;
        this.toggleX = 96;
        this.toggleY = 62;
        this.toggleW = 20;
        this.toggleH = 18;
        this.buttons = [];
        this.hoverIdx = -1;
        this.open = false;
        this.wasOpen = false;
        this.searchText = '';
        this.searchFocused = false;
        this.searchX = -130;
        this.searchY = 13;
        this.searchW = 82;
        this.searchH = 13;
    }

    init() {
        this.textureToggle = this.getTexture("gui/RecipeBook/RecipeBook.png");
        this.textureBtn = this.getTexture("gui/RecipeBook/RecipeF.png");
        this.textureRecipeT = this.getTexture("gui/RecipeBook/RecipeT.png");
        this.textureBtnHover = this.getTexture("gui/RecipeBook/RecipeBook1.png");
        this.textureGui = this.getTexture("gui/RecipeBook/RecipeBookGUI.png");
        this.loadConfig();
    }

    loadConfig() {
        this.buttons = [
            {x:-144,y:29,w:26,h:24},{x:-119,y:29,w:26,h:24},{x:-144,y:53,w:26,h:24},{x:-44,y:101,w:26,h:24},
            {x:-69,y:101,w:26,h:24},{x:-94,y:29,w:26,h:24},{x:-69,y:29,w:26,h:24},{x:-44,y:29,w:26,h:24},
            {x:-44,y:77,w:26,h:24},{x:-94,y:101,w:26,h:24},{x:-119,y:53,w:26,h:24},{x:-94,y:53,w:26,h:24},
            {x:-69,y:53,w:26,h:24},{x:-69,y:77,w:26,h:24},{x:-144,y:101,w:26,h:24},{x:-44,y:53,w:26,h:24},
            {x:-144,y:77,w:26,h:24},{x:-119,y:77,w:26,h:24},{x:-94,y:77,w:26,h:24},{x:-119,y:101,w:26,h:24}
        ];
    }

    checkUnlock(inventory) {
        if (RecipeBook.unlocked) return;
        if (!inventory || !inventory.items) return;
        for (let i = 0; i < inventory.items.length; i++) {
            if (inventory.items[i] && inventory.items[i].getType() === 17) {
                RecipeBook.unlocked = true;
                return;
            }
        }
    }

    toggle() {
        if (!this.open && this.minecraft?.player) {
            this.checkUnlock(this.minecraft.player.inventory);
        }
        this.setOpen(!this.open);
    }

    setOpen(value) {
        if (this.open === value) return;
        this.open = value;
        if (!this.open) {
            this.searchFocused = false;
            if (this.minecraft?.itemRenderer) {
                this.minecraft.itemRenderer.destroy("recipeBook");
            }
        }
    }

    isOpen() {
        return this.open;
    }

    draw(stack, containerX, containerY, mouseX, mouseY) {
        if (!this.textureToggle) return;

        const absTx = containerX + this.toggleX;
        const absTy = containerY + this.toggleY;

        if (this.open) {
            if (this.textureBtn) {
                const useRecipeT = RecipeBook.unlocked && this.textureRecipeT;
                const itemRenderer = this.minecraft.itemRenderer;
                const planksBlock = Block.getById(5);

                for (let i = 0; i < this.buttons.length; i++) {
                    const b = this.buttons[i];
                    const absX = containerX + b.x;
                    const absY = containerY + b.y;
                    const over = mouseX >= absX && mouseX < absX + b.w && mouseY >= absY && mouseY < absY + b.h;
                    if (over) this.hoverIdx = i;

                    const btnTex = useRecipeT ? this.textureRecipeT : this.textureBtn;
                    this.drawSprite(stack, btnTex, 0, 0, btnTex.naturalWidth, btnTex.naturalHeight, absX, absY, b.w, b.h);

                    if (i === 0 && itemRenderer && planksBlock) {
                        itemRenderer.renderItemInGui("recipeBook", "btn_" + i, planksBlock, absX + 13, absY + 12);
                    }
                }
            }

            const sbAbsX = Math.floor(containerX + this.searchX);
            const sbAbsY = Math.floor(containerY + this.searchY);
            const padX = 3;
            const padY = 2;

            stack.fillStyle = '#000000';
            stack.fillRect(sbAbsX, sbAbsY, this.searchW, this.searchH);
            stack.strokeStyle = this.searchFocused ? '#ffffff' : '#888888';
            stack.lineWidth = 1;
            stack.strokeRect(sbAbsX + 0.5, sbAbsY + 0.5, this.searchW - 1, this.searchH - 1);

            if (this.searchFocused) {
                if (this.searchText) {
                    this.drawString(stack, this.searchText, sbAbsX + padX, sbAbsY + padY, 0xFFFFFF, false);
                }
            } else if (this.searchText) {
                this.drawString(stack, this.searchText, sbAbsX + padX, sbAbsY + padY, 0xFFFFFF, false);
            } else {
                this.drawString(stack, 'Search...', sbAbsX + padX, sbAbsY + padY, 0x888888, false);
            }
        }

        const overToggle = mouseX >= absTx && mouseX < absTx + this.toggleW && mouseY >= absTy && mouseY < absTy + this.toggleH;
        this.drawSprite(stack, overToggle ? this.textureBtnHover : this.textureToggle, 0, 0, this.textureToggle.naturalWidth, this.textureToggle.naturalHeight, absTx, absTy, this.toggleW, this.toggleH);
    }

    drawGui(stack, guiX, guiY) {
        if (!this.open || !this.textureGui) {
            if (this.wasOpen) {
                this.wasOpen = false;
            }
            return;
        }
        this.wasOpen = true;
        this.drawSprite(stack, this.textureGui, 0, 0, this.textureGui.naturalWidth, this.textureGui.naturalHeight, guiX, guiY, this.textureGui.naturalWidth, this.textureGui.naturalHeight);
    }

    isMouseOver(mouseX, mouseY, containerX, containerY) {
        const absTx = containerX + this.toggleX;
        const absTy = containerY + this.toggleY;
        if (mouseX >= absTx && mouseX < absTx + this.toggleW && mouseY >= absTy && mouseY < absTy + this.toggleH) return true;
        if (this.open) {
            for (const b of this.buttons) {
                const absX = containerX + b.x;
                const absY = containerY + b.y;
                if (mouseX >= absX && mouseX < absX + b.w && mouseY >= absY && mouseY < absY + b.h) return true;
            }
            const sbAbsX = containerX + this.searchX;
            const sbAbsY = containerY + this.searchY;
            if (mouseX >= sbAbsX && mouseX < sbAbsX + this.searchW && mouseY >= sbAbsY && mouseY < sbAbsY + this.searchH) return true;
        }
        return false;
    }

    getClickedIndex(mouseX, mouseY, containerX, containerY) {
        if (this.open) {
            for (let i = 0; i < this.buttons.length; i++) {
                const b = this.buttons[i];
                const absX = containerX + b.x;
                const absY = containerY + b.y;
                if (mouseX >= absX && mouseX < absX + b.w && mouseY >= absY && mouseY < absY + b.h) return i;
            }
        }
        return -1;
    }

    onClick(mouseX, mouseY, containerX, containerY) {
        const absTx = containerX + this.toggleX;
        const absTy = containerY + this.toggleY;
        if (mouseX >= absTx && mouseX < absTx + this.toggleW && mouseY >= absTy && mouseY < absTy + this.toggleH) {
            this.toggle();
            return true;
        }
        if (this.open) {
            const sbAbsX = containerX + this.searchX;
            const sbAbsY = containerY + this.searchY;
            if (mouseX >= sbAbsX && mouseX < sbAbsX + this.searchW && mouseY >= sbAbsY && mouseY < sbAbsY + this.searchH) {
                this.searchFocused = true;
                return true;
            }
            this.searchFocused = false;

            for (const b of this.buttons) {
                const absX = containerX + b.x;
                const absY = containerY + b.y;
                if (mouseX >= absX && mouseX < absX + b.w && mouseY >= absY && mouseY < absY + b.h) {
                    this._fillCraftingWithOakLog();
                    return true;
                }
            }
        }
        return false;
    }

    _fillCraftingWithOakLog() {
        const OAK_LOG_ID = 17;
        const player = this.minecraft?.player;
        if (!player) return;

        const inv = player.inventory;
        if (!inv || !inv.items) return;

        let totalCount = 0;
        const restorable = [];

        for (let i = 0; i < 36; i++) {
            const stack = inv.getItemInSlot(i);
            if (stack && stack.getType() === OAK_LOG_ID && !stack.isEmpty()) {
                totalCount += stack.getCount();
                restorable.push({ index: i, count: stack.getCount() });
                inv.setItem(i, new ItemStack(0, 0));
            }
        }

        if (totalCount === 0) return;

        const screen = this.minecraft.currentScreen;
        if (!screen || !screen.container) return;

        const container = screen.container;

        const craftingSlots = this._getCraftingSlots(container);
        if (!craftingSlots) return;

        const targetInv = craftingSlots.inventory;
        const targetIdx = craftingSlots.index;
        const existing = targetInv.getItemInSlot(targetIdx);

        if (existing && !existing.isEmpty() && existing.getType() !== OAK_LOG_ID) {
            for (const r of restorable) {
                inv.setItem(r.index, existing.copy());
            }
            return;
        }

        targetInv.setItem(targetIdx, new ItemStack(OAK_LOG_ID, totalCount));

        if (typeof container.refreshCraftingResult === 'function') {
            container.refreshCraftingResult();
        }
        container.dirty = true;
    }

    _getCraftingSlots(container) {
        const ctor = container.constructor.name;
        if (ctor === 'ContainerSurvival' || ctor === 'ContainerPlayer') {
            return { inventory: this.minecraft.player.inventory, index: 46 };
        }
        const craftingInv = container.craftingInventory;
        if (craftingInv) {
            return { inventory: craftingInv, index: 0 };
        }
        return null;
    }

    handleKey(key, character, containerX, containerY) {
        if (!this.searchFocused) return false;
        if (key === 'Escape') {
            this.searchFocused = false;
            return true;
        }
        if (key === 'Backspace') {
            this.searchText = this.searchText.slice(0, -1);
            return true;
        }
        if (key === 'Enter') {
            this.searchFocused = false;
            return true;
        }
        if (character && character.length === 1) {
            this.searchText += character;
            return true;
        }
        return false;
    }

}
