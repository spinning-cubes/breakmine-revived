import Block from "../Block.js";
import Explosive from "./Explosive.js";

export default class BlockBigTnt extends Explosive {

    constructor(id, textureSlotId) {
        super(id, textureSlotId, 6, 6.0);
        this.description = "Big TNT Block";
        this.inventoryTab = EnumCreativeInventoryTab.TOOLS;
        this.hardness = 0.1;
        this.sound = Block.sounds.grass;
    }

    getTextureForFace(face) {
        switch (face) {
            case EnumBlockFace.TOP:
            case EnumBlockFace.BOTTOM:
                return 'bombcraft:tntGreenBottom';
            default:
                return 'bombcraft:tntGreenSide';
        }
    }
}