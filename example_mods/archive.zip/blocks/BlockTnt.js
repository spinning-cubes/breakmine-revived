import Block from "../Block.js";
import Explosive from "./Explosive.js";

export default class BlockTnt extends Explosive {

    constructor(id, textureSlotId) {
        super(id, textureSlotId, 4, 4.0);
        this.description = "TNT Block";
        this.inventoryTab = EnumCreativeInventoryTab.TOOLS;
        this.hardness = 0.1;
        this.sound = Block.sounds.grass;
    }

    getTextureForFace(face) {
        switch (face) {
            case EnumBlockFace.TOP:
            case EnumBlockFace.BOTTOM:
                return 'bombcraft:tntBottom';
            default:
                return 'bombcraft:tntSide';
        }
    }
}