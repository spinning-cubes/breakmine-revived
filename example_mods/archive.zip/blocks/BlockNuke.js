import Block from "../Block.js";
import Explosive from "./Explosive.js";

export default class BlockNuke extends Explosive {

    constructor(id, textureSlotId) {
        super(id, textureSlotId, 50, 50.0);
        this.description = "Nuke";
        this.inventoryTab = EnumCreativeInventoryTab.TOOLS;
        this.hardness = 0.1;
        this.sound = Block.sounds.grass;
    }

    getTextureForFace(face) {
        return 'bombcraft:nuke';
    }
}