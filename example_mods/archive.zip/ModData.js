export default class ModData {
    static NAME = "BombCraft";

    static ID = "bombcraft";

    static AUTHOR = "LowQualityCoding";
    
    static VERSION = "0.0.1";
}